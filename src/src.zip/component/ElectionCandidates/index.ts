export { default } from "./ElectionCandidates";
