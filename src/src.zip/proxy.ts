import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function proxy(request: NextRequest) {
  const loginUrl = request.nextUrl.clone();
  loginUrl.pathname = "/Login";

  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ["/"],
};
